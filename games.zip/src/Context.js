import React from "react";

function Context() {
  return <div>Context</div>;
}

export default Context;
