import React from "react";

function Write() {
  return <div>Write</div>;
}

export default Write;
